#@HZ

def get_ann(samples):
    '''
    create mapping between genomic variant and HGVSp short
    input: 
    - samples: can be a single missionbio.mosaic.sample.Sample instance, 
               or a list of that instance
    return:
    - ann_map: maps genomic info to protein info
               e.g. 'chr12:25398284:C/T': '(PATH) KRAS:p.G12D '
    '''
    if isinstance(samples, dict):
        samples = list(samples.values())
        
    if isinstance(samples, list):
        map_list = []
        for i in range(len(samples)):
            annotation_map = {}
            for j, k in zip(samples[i].dna.ids(), samples[i].dna.get_annotations()):
                annotation_map[j] = k.split('-')[0]
                map_list.append(annotation_map)
        ann_map = {}
        for d in map_list:
            ann_map.update(d)
        return ann_map
    
    elif isinstance(samples, mio.Sample):
        annotation_map = {}
        for j, k in zip(samples.dna.ids(), samples.dna.get_annotations()):
            annotation_map[j] = k.split('-')[0]
            return annotation_map
    else:
        print("input error")


def sort_for_var(dna, vars, attribute, method='hier'):

    '''
    function to sort a particular set of barcodes for DNA values
    
    input:
    - dna: a single missionbio.mosaic.sample.Sample.dna instance
    - vars: a list of variants of the form 'chr12:25398284:C/T'
    - attribute: "AF_MISSING", "NGT" etc.
    - method: 'hier' (multiple vars) or 'single var' (single var, ascending value)
    
    return:
      ordered cell barcodes (hierarhchically)
    '''
    if method == 'hier':
        if not isinstance(vars, list):
            vars = [vars]
        assay = dna[dna.barcodes(), vars]
        return assay.clustered_barcodes(orderby = attribute)
        
    elif method == 'single_var':
        if not isinstance(vars, list):
            vars = [vars]
        
        data = dna.get_attribute(attribute, constraint = 'row')
        return data.sort_values(by=vars).index

def label_for_var(sample, vars_of_interest, GQ_threshold=30, AF_threshold=20):
    '''
    function to create label based on the VAF of a particular set of variants, with the option to filter based on genomic variant quality (GQ). 
    '''

    if not isinstance(vars_of_interest, list):
        vars_of_interest = [vars_of_interest]
        
    # get cells with low-quality KRAS genotype
    GQ_df = sample.dna.get_attribute('GQ', constraint='row+col')
    low_q_cells = GQ_df[vars_of_interest].index[((GQ_df[vars_of_interest] < GQ_threshold).sum(axis=1) > 0) == True].tolist()
    
    # get mutant cells
    AF_df = sample.dna.get_attribute('AF_MISSING', constraint='row+col')
    mut_cells = AF_df[vars_of_interest].index[((AF_df[vars_of_interest] > AF_threshold).sum(axis=1) > 0) == True].tolist()
    
    sample.dna.set_labels(clusters = {'mutant_cells': mut_cells, \
                                      'low_q_cells': low_q_cells}, \
                          others_label='others')
