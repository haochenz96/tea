# Tapestri Express Analysis

For fast analysis of Tapestri results (h5 matrices).
Detailed descrition to follow...