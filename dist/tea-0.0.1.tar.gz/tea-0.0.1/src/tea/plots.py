

from matplotlib_venn import venn2, venn2_circles, venn2_unweighted

def h_heatmap(dna, attribute='AF_MISSING', features=None, bars_order=None, \
    sort_for_var=None, sort_mode = ''):
    
    if features is None:
        features = dna.clustered_ids(orderby=attribute)
    
    if sort_for_var is not None:
        if not isinstance(orderby, list):
            print('sort_for takes a list as input, even for one variant')
            raise NotImplementedError
        elif len(sort_for_var) > 1
            bars_order = sort_for_var(dna, sort_for, attribute, method='hier')
        else: 
            bars_order = sort_for_var(dna, sort_for, attribute, method='single_var')
    else:
        bars_order = self.clustered_barcodes(orderby=attribute)


    if not np.isin(features, self.ids()).all():
        # @HZ
        print("Warning: not all the given features were found in the assay ids.")
        #raise ValueError("Not all the given features were found in the assay ids.")
        
        data = self.get_attribute(attribute, constraint='row', features=np.intersect1d(features, self.ids()).tolist())

        # append the missing features as undetected (value = 0)
        for feature in list(set(features) - set(self.ids())):

            print(f'{feature} not in ids')
            data[feature] = np.zeros([data.shape(0), 1]) # @HZ: potentially problematic because it only applies to dna
    else:
        data = self.get_attribute(attribute, constraint='row', features=features)

    data = data.loc[bars_order, :]

    cell_num = data.shape[0]
    feature_num = data.shape[1]

    fig = make_subplots(rows=1, cols=1)
                            # shared_yaxes=True,
                            # horizontal_spacing=0.01,
                            # column_widths=[1 / 25, 24 / 25])

    vals = go.Heatmap(z=data,
                          x=np.arange(cell_num),
                          y=data.columns,
                          coloraxis='coloraxis',
                          hovertemplate='%{z:.2f}<br>%{x}<extra>%{customdata}</extra>',
                          showlegend=False,
                          showscale=False)
    fig.add_trace(vals, row=1, col=2)




def venn_diagram(dna, variants, AF_threshold=15, annotate=None):

    '''
    function to create Venn Diagram to visualize
    
    input:
    - dna: a single missionbio.mosaic.sample.Sample.dna instance
    - variants: a list of variants of the form 'chr12:25398284:C/T'
    - AF_threshold: the lowest allele frequency to call a variant to be real in a cell
    
    return:
        venn diagram (matplot figure)
    '''

    if type(variants) != list or len(variants) > 3:
        print('please input a list of 2 or 3 variants')
        raise NotImplementedError
    
    venn_sets = []
    for var in variants:
        df = dna.get_attribute('AF_MISSING', constraint = 'row')[var]
        mut_set  = set(df.loc[df > AF_threshold].index)
        venn_sets.append(mut_set)
    
    # annotation
    if annotate is not None:
        annotation = [f'{annotate[var]} mutated cells' for var in variants]
    else:
        annotation = None

    if len(variants) == 2:
        fig = venn2(venn_sets, annotation,\
                   set_colors=('purple', 'skyblue'), alpha = 0.5)
    else:
        fig = venn3(venn_sets, annotation,\
                   set_colors=('purple', 'skyblue', 'yellow'), alpha = 0.5)

    return fig

##############
# single cell heatmap
# ['RA17_22_35_1', 'RA17_22_39_13', 'RA17_22_39_13_prvd', 'RA17_22_39_2']
i = 'RA17_22_39_2'
attribute = "AF_MISSING"
var_to_sortby = 'chr12:25398284:C/A' # sort by KRAS p.G12V
k = .5 # scaling factor for 


cell_num = samples[i].dna.shape[0]
print(f'sample {i} has cell number {cell_num}')

sorted_barcodes = utils.sort_for_var(samples[i], \
                               vars = var_to_sortby, \
                               attribute = 'AF_MISSING', \
                              method = 'single_var') # sort for KRAS

fig = samples[i].dna.heatmap(attribute=attribute, \
                            bars_order = sorted_barcodes,
                            features = variants[i])

fig.update_xaxes(ticktext=[ann_map[var] for var in fig.layout.xaxis.ticktext.tolist()],\
                tickangle= 45, tickfont=dict(family='Arial', color='crimson', size=8),\
                tickvals = [i-0.4 for i in np.arange(len(fig.layout.xaxis.ticktext.tolist()))])

if attribute == "AF_MISSING":
    fig.layout.coloraxis.colorscale = [[0, 'rgb(255,255,51)'], [1/3, 'rgb(204,229,255)'], [1, 'rgb(255,0,0)']]

fig_height = cell_num * 0.3 *k
if fig_height < 800:
    fig_height = 800

plot_attr = ''
if attribute == 'AF_MISSING':
    plot_attr = 'variant allele frequency'
elif attribute == 'NGT':
    plot_attr = 'genotype'

fig.update_layout(width = 400, height=fig_height,\
                 title_text = f'{i} single cell {plot_attr} heatmap <br><sup>cells sorted by KRAS single cell VAF </sup>',\
                 title_x = 0.5, title_xanchor = 'center', title_yanchor = 'top')


fig.write_image(f'{i}_sc_{attribute}_heatmap.pdf')



##################
# per amplicon ploidy plot
cluster='norm_c'

fig=sample_1.cnv.plot_ploidy(cluster=cluster)

# map amplicon to genomic locations
ids, features = sample_1.cnv._get_ids_from_features('positions')
un, ind, cnts = np.unique(features, return_index=True, return_counts=True)
ticks = (ind + cnts / 2).astype(int)
fig.layout.xaxis.ticktext = features[ticks]
fig.layout.xaxis.tickvals = ticks
fig.data[0].x = ids + '<br>' + features

for i in ind:
    fig.add_vline(i -0.5, line_color='red', line_width=2, row=1, col=1, opacity=0.2)

fig.update_xaxes(showgrid=False)
    
fig.write_image(f'{sample_i}_amplicon_ploidy_count_{cluster}.pdf')