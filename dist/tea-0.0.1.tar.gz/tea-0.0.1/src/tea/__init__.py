"""Top-level package for tea."""

__author__ = """HZ"""
__email__ = 'haochenz1996@gmail.com'
__version__ = '0.1.0'
